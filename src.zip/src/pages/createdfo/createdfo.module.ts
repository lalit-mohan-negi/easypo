import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CreatedfoPage } from './createdfo';

@NgModule({
  declarations: [
    CreatedfoPage,
  ],
  imports: [
    IonicPageModule.forChild(CreatedfoPage),
  ],
})
export class CreatedfoPageModule {}
